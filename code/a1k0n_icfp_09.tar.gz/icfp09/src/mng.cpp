// meet n' greet
// works with both bin2.obf and bin3.obf

#include "vm.h"
#include "osf.h"
#include "orbit.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static int timestep = 0;
static vector2 s_(0,0), s, v; // s_ is the previous frame's position
static vector2 target_(0,0), target, targetv;

void sim_step(vector2 thrust, bool do_print = false)
{
  if(timestep < 3 || timestep%1000 == 0) do_print = true;
  osf_thrust(timestep, thrust.x, thrust.y);

  if(thrust.x != 0 || thrust.y != 0)
    printf("impulse @t%d: (%f,%f)\n", timestep, thrust.x, thrust.y);

  vm_step();
  timestep++;
  s_ = s;
  s = vector2(oport[2], oport[3]);
  v = predict_v1(s_, s, thrust);
  target_ = target;
  target = s - vector2(oport[4], oport[5]);
  targetv = predict_v1(target_, target, z2);

  if(do_print) {
    printf("---step %d\n", timestep);
    printf("score : %f\n", oport[0]);
    printf("fuel  : %f\n", oport[1]);
    printf("s%d = (%f,%f)\n", timestep, s.x, s.y);
    printf("r%d = %f\n", timestep, abs(s));
    printf("ts%d = (%f,%f)\n", timestep, target.x, target.y);
    printf("targetdist = %f\n", abs(s-target));
    if(timestep > 1) {
      printf("v%d = (%f,%f)\n", timestep, v.x, v.y);
      printf("tv%d = (%f,%f)\n", timestep, targetv.x, targetv.y);
      double nu;
      orbit o = calc_orbit(nu, trajectory(s,v));
      printf("our orbit: nu=%f; ", nu); o.print(); printf("\n");
      o = calc_orbit(nu, trajectory(target,targetv));
      printf("target orbit: nu=%f; ", nu); o.print(); printf("\n");
    }
  }
  // are we done?
  if(oport[0] != 0) {
    printf("done at step %d, score = %f\n", timestep, oport[0]);
    close_osf(timestep);
    exit(0);
  }
} 

void intercept_target(double meet_time, double radius)
{
  while(timestep < meet_time-4) sim_step(z2, false);
  // project forward in time, find minimum delta v timestep

  vector2 Dv1, Dv2;
  int min_i=0;
  double min_Dv=0;

  vector2 s0=s, v0=v, ts0=target, tv0=targetv;
  vector2 s1,v1, ts1,tv1, ts2,tv2;
  s1 = predict_s1(s0,v0,z2); v1 = predict_v1(s0,s1,z2);
  ts1 = predict_s1(ts0,tv0,z2); tv1 = predict_v1(ts0,ts1,z2);
  ts2 = predict_s1(ts1,tv1,z2); tv2 = predict_v1(ts1,ts2,z2);

  for(int i=0;;i++) {
    vector2 Dv1_,Dv2_;
    double Dv = min_adjust_maneuver(Dv1_,Dv2_,s0,v0, ts2,tv2, radius);
    printf("intercept @t=%d; Dv=%f\n", timestep+i, Dv);
    if(i==0 || Dv < min_Dv) { min_i = i; min_Dv = Dv; Dv1=Dv1_; Dv2=Dv2_; }
    else break;
    s0=s1; v0=v1;
    s1 = predict_s1(s0,v0,z2); v1 = predict_v1(s0,s1,z2);
    ts1=ts2; tv1=tv2;
    ts2 = predict_s1(ts1,tv1,z2); tv2 = predict_v1(ts1,ts2,z2);
  }
  for(int j=0;j<min_i;j++) sim_step(z2, j > min_i - 2);

  sim_step(Dv1, true);
  sim_step(Dv2, true);
}

void transfer_orbit(const orbit &o, double transfer_time, double radius)
{
  double nu;
  vector2 Dv1(0,0), Dv2(0,0);

#if 0
  // just wait out until our time hint
  while(timestep < transfer_time-2) sim_step(z2, timestep > transfer_time - 4);

  o.transfer_maneuver(Dv1, Dv2, s, v);

#else
  while(timestep < transfer_time-20) sim_step(z2, false);
  // now, project forward in time and find the minimum transfer fuel
  double min_Dv=0;
  vector2 fs=s, fv=v; // forward position and velocity
  int min_i=0;
  // just assume that total delta-v is going to decrease over time, then increase again
  // (as long as our time projection isn't totally hosed that should be true)
  for(int i=0;;i++) {
    vector2 v1, v2;
    double Dv = o.transfer_maneuver(v1, v2, fs, fv, radius);
    printf("t=%d Dv=%f s=(%f,%f) v=(%f,%f)\n", timestep+i, Dv, fs.x, fs.y, fv.x, fv.y);
    if(i==0 || Dv < min_Dv) { Dv1 = v1; Dv2 = v2; min_Dv = Dv; min_i = i; }
    else break;
    vector2 fs_ = predict_s1(fs, fv, z2);
    fv = predict_v1(fs, fs_, z2);
    fs = fs_;
  }

  for(int j=0;j<min_i;j++) sim_step(z2, j > (min_i - 3));
#endif

  printf(" --- initiating orbital transfer @t=%d to desired orbit:\n", timestep);
  o.print(); printf("\n");

  printf("s%d = (%f,%f)\n", timestep, s.x, s.y);
  printf("v%d = (%f,%f)\n", timestep, v.x, v.y);

  orbit present = calc_orbit(nu, trajectory(s,v));
  printf("initial orbit: nu=%f; ", nu); present.print(); printf("\n");

  printf("executing maneuver V1(%f,%f) V2(%f,%f)\n", Dv1.x, Dv1.y, Dv2.x, Dv2.y);
  sim_step(Dv1, true);
  sim_step(Dv2, true);

  present = calc_orbit(nu, trajectory(s,v));
  printf("final orbit: nu=%f; ", nu); present.print(); printf("\n");
  printf(" --- orbital transfer completed @t=%d\n", timestep);
}


int main(int argc, char **argv)
{
  if(argc < 4) {
    printf("usage: %s <bin2.obf> <scenario> <output.osf>\n", argv[0]);
    return 0;
  }

  read_obf(argv[1]);
  open_osf(argv[3], atoi(argv[2]));

  sim_step(z2,true);
  sim_step(z2,true);

  double nu;
  orbit present = calc_orbit(nu, trajectory(s,v));
  //printf("present trajectory: r=(%f,%f) v=(%f,%f)\n", s.x, s.y, v.x, v.y);
  //printf("present orbit: nu=%f; ", nu); present.print(); printf("\n");

  orbit target_orbit = calc_orbit(nu, trajectory(target,targetv));
  //printf("target trajectory: r=(%f,%f) v=(%f,%f)\n", target.x, target.y, targetv.x, targetv.y);
  //printf("target orbit: nu=%f; ", nu); target_orbit.print(); printf("\n");

  // now!  we can project forward in time and see where the target satellite
  // would be if we were to do a Hormann transfer onto its orbit from our
  // present location, and then determine if we are ahead of or behind it, and
  // bisect to find the optimal time to catch it.  or we can just poll for a
  // suitable time to transfer.

  double t;
  double nu0, nu1;
  t = timestep + next_transfer_time(nu1, nu0, present, present.true_anomaly(s), 
                                    target_orbit, target_orbit.true_anomaly(target));
  printf("next closest approach @%f, nu@o1 = %f, nu@o2 = %f\n", t, nu0, nu1);

  orbit ideal_transfer(present.position(nu0), target_orbit.radius(nu1));

  {
    vector2 sproj = present.position(nu0);
    vector2 vproj = present.velocity(sproj, z2);
    printf("projected sat trajectory at transfer t%f: s(%f,%f) v(%f,%f)\n", t,
           sproj.x, sproj.y, vproj.x, vproj.y);
    sproj = target_orbit.position(nu1);
    vproj = target_orbit.velocity(sproj, z2);
    printf("projected target trajectory at meet t%f: s(%f,%f) v(%f,%f)\n", t + ideal_transfer.period()/2,
           sproj.x, sproj.y, vproj.x, vproj.y);
  }

  // transfer onto our transfer orbit
  transfer_orbit(ideal_transfer, t, 0);
  // transfer onto the target orbit
  //transfer_orbit(target_orbit, t + ideal_transfer.period()/2);
  intercept_target(t + ideal_transfer.period()/2, 999);


  // and run it through to win (maybe)
  for(int i=0;i<3000;i++) { sim_step(z2, false); }
}

