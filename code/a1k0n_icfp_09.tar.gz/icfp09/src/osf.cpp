#include <stdio.h>
#include "vm.h"

FILE *osf;
void open_osf(const char *fname, int scenario)
{
  osf = fopen(fname, "wb");
  unsigned header = 0xcafebabe;
  unsigned team = 231;
  fwrite(&header, 4, 1, osf);
  fwrite(&team, 4, 1, osf);
  fwrite(&scenario, 4, 1, osf);

  int count = 1;
  int timestep = 0;
  int addr = 0x3e80;
  double sc_double = scenario;
  fwrite(&timestep, 4, 1, osf);
  fwrite(&count, 4, 1, osf);
  fwrite(&addr, 4, 1, osf);
  fwrite(&sc_double, 8, 1, osf);
  iport[0x3e80] = scenario;
}

void close_osf(int timestep)
{
  int count = 0;
  fwrite(&timestep, 4, 1, osf);
  fwrite(&count, 4, 1, osf);
  fclose(osf);
}

void osf_thrust(int timestep, double Vx, double Vy)
{
  Vx = -Vx;
  Vy = -Vy;
  if(iport[2] == Vx && iport[3] == Vy)
    return;
  
  int count = 2;
  int addr = 2;
  fwrite(&timestep, 4, 1, osf);
  fwrite(&count, 4, 1, osf);
  fwrite(&addr, 4, 1, osf);
  fwrite(&Vx, 8, 1, osf);
  addr = 3;
  fwrite(&addr, 4, 1, osf);
  fwrite(&Vy, 8, 1, osf);
  iport[2] = Vx;
  iport[3] = Vy;
}


