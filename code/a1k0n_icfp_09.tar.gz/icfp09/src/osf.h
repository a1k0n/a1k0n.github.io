#include <stdio.h>

extern void open_osf(const char *fname, int scenario);
extern void close_osf(int timestep);
extern void osf_thrust(int timestep, double Vx, double Vy);

