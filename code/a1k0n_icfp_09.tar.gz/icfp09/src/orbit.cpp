#include <math.h>
#include <stdio.h>
#include "orbit.h"
#include <stdlib.h>

// calculate orbital parameters from position and velocity
orbit calc_orbit(double &nu, trajectory t)
{
  double v2 = t.v*t.v;
  double r = abs(t.r);
  orbit o;

  // the semimajor axis can be derived with the vis-viva equation:
  o.a = Gme*r/(2*Gme - v2*r);

  // eccentricity can be found from the specific orbital energy
  // which requires that we calculate h^2, the specific relative angular momentum
  // h = r x v
  // in 2-space the cross product is a scalar, so
  o.h = t.r%t.v;
  o.p = o.h*o.h/Gme; // h^2 over mu = semi-latus rectum p

  // now, eccentricity vector
  o.e = (v2*t.r - (t.r*t.v)*t.v)/Gme - t.r/r;
  o.emag = abs(o.e);

  nu = o.true_anomaly(t.r);

  return o;
}

// solve Kepler equation by Netwon's Method
double KeplerE(double M, double e)
{
  double E = M;
  double dE;
  do {
    dE = (M + e*sin(E) - E)/(1 - e*cos(E));
    E += dE;
  } while(fabs(dE) > 1e-8);
  return E;
}

double KeplerM(double E, double e)
{
  return E - e*sin(E);
}

// circular orbit with no eccentricity
orbit::orbit(double radius): e(0,0), emag(0), p(radius), a(radius)
{
  // hmm, are we going to have to deal with orbits going both ways?
  h = -sqrt(p*Gme);
}

// Hohmann transfer orbit
orbit::orbit(vector2 R0, double r1)
{
  double r0 = abs(R0);
  a = (r0+r1)/2;
  emag = (r1-r0)/(r0+r1);
  p = 2*r0*r1/(r0+r1);
  h = -sqrt(p*Gme);
  e = emag * R0/r0; // eccentricity vector points towards r0
  emag = fabs(emag);
}

// cur_v is only used to determine orbit direction
vector2 orbit::velocity(vector2 r, vector2 cur_v) const
{
  vector2 v = Gme/h % (e + r/abs(r));
  if(v*cur_v < 0) return -v;
  return v;
}

#if 0
vector2 orbit::project_forward(vector2 r0, double t) const
{
  // ok, this is the tricky bit.
  // first, find our current true anomaly
  double nu = true_anomaly(r0);
  // now convert to eccentric anomaly
  double efactor = sqrt((1+emag)/(1-emag));
  double E = 2*atan(tan(nu/2)/efactor);
  // mean anomaly
  double M = KeplerM(E, emag);
  // time
  double t0 = M/sqrt(Gme/(a*a*a));
  // compensate for new time (but our orbits are backwards)
  M *= (-t+t0)/t0;
  // back to eccentric anomaly
  E = KeplerE(M, emag);
  // back to nu
  nu = 2*atan(tan(E/2)*efactor);
  // and then to a position from the angle and orbital radius
  return position(nu);
}
#endif

double orbit::forward_angle(double nu, double t) const
{
#if 0
  double efactor = sqrt((1+emag)/(1-emag));
  double E = 2*atan(tan(nu/2)/efactor);
  // mean anomaly
  double M = KeplerM(E, emag);
  // time
  double t0 = M/sqrt(Gme/(a*a*a));
  // compensate for new time (but our orbits are backwards)
  M *= (-t+t0)/t0;
  // back to eccentric anomaly
  E = KeplerE(M, emag);
  // back to nu
  nu = 2*atan(tan(E/2)*efactor);
  return nu;
#else
  // the above doesn't account for the integration error.  this is slow but does.
  // turns out the difference is extremely small.
  vector2 s = position(nu), s1;
  vector2 v = velocity(s, z2);
  int i;
  for(i=0;i<t;i++) {
    s1 = predict_s1(s, v, z2);
    v = predict_v1(s, s1, z2);
    s = s1;
  }
  t -= i;
  // interpolate last fractional second
  s1 = s + v*t + t*t*g(s)/2;
  //v += t*(g(s)+g(s1))/2;
  return true_anomaly(s1);
#endif
}

// if we transfer onto o, where will we meet it?
vector2 transfer_dest(const orbit &o, vector2 r)
{
  double r1 = abs(r);
  vector2 r1hat = r/r1;
  double cosnu = -r1hat*(o.e/o.emag);
  double r2 = o.p/(1+o.emag*cosnu);
  return -r2*r1hat;
}

// how long will a transfer onto orbit o from r take?
double transfer_time(const orbit &o, vector2 r)
{
#if 1
  // this is apparently wrong!
  double r1 = abs(r);
  double cosnu = (-r/r1)*(o.e/o.emag);
  double r2 = o.p/(1+o.emag*cosnu);
  r2 += r1;
  return M_PI*sqrt(r2*r2*r2/(8*Gme));
#else
  orbit transfer(r, o.radius(o.true_anomaly(r)+M_PI));
  return transfer.period()/2;
#endif
}

static inline int rad2deg(double a) { return 180*a/M_PI; }

static double transfer_diffangle(double &destnu, double &srcnu, 
                                 double &Ttrans,
                                 const orbit &o1, double o1nu, 
                                 const orbit &o2, double o2nu, double t)
{
  srcnu = o1.forward_angle(o1nu, t);

  // object 1 nu in o2's orbit after transfer (simply the opposite side of the present position)
  o1nu = o2.true_anomaly(o1.position(srcnu+M_PI));

  Ttrans = transfer_time(o2, o1.position(srcnu));
  //printf("Ttrans @ t%f -> %f\n", t, Ttrans);
  // object 2 nu after transfer
  o2nu = o2.forward_angle(o2nu, t+Ttrans);
  double diff = o1nu - o2nu;
  if(diff < -M_PI) diff += 2*M_PI;
  if(diff > M_PI) diff -= 2*M_PI;
  //printf("angle @ t%f -> Ttrans=%f srcnu=%d o1nu=%d o2nu=%d diff=%d\n", t, Ttrans,
  //       rad2deg(srcnu), rad2deg(o1nu), rad2deg(o2nu), rad2deg(diff));
  destnu = o2nu;
  return diff;
}

double next_transfer_time(double &destnu, double &srcnu,
                          const orbit &o1, double o1nu,
                          const orbit &o2, double o2nu)
{
  double t0 = 0;
  double t = 10;
  double a;
  double max_step = fmin(o1.period()/4, o2.period()/4);
  // use a newton's method approximation (since I haven't tried to
  // differentiate dnu/dt.. kepler's equation kinda makes that hard)
  // AKA the secant method
  double Ttrans;
  double a0 = transfer_diffangle(destnu, srcnu, Ttrans, o1, o1nu, o2, o2nu, t0);
  for(int itr=0;;itr++) {
    a = transfer_diffangle(destnu, srcnu, Ttrans, o1, o1nu, o2, o2nu, t);
    double dt = (t0-t)*a/(a-a0);
    // we can't be finding orbits before time zero, so step ahead by a quarter cycle
    if(t+dt < 0) { dt = max_step; }
    if(dt > max_step) dt = max_step;
    if(dt < -max_step*0.7) dt = -max_step*0.7; // this is kind of silly, but it keeps it from cycling forever
    //printf("secant dt step: t=%f t0=%f a=%f a0=%f dt=%f (maxstep=%f)\n", t, t0, a, a0, dt, max_step);
    a0 = a; t0 = t; t += dt;
    if(fabs(dt) < 1e-10) break;
    if(itr > 100) return 2e6;
  }
  printf("orbit: current -> t=%f -> transfer -> t=%f -> target\n", t, t+Ttrans);
  return t;
}

double adjust_maneuver(vector2 &Dv1, vector2 &Dv2, vector2 s0, vector2 v0, vector2 s2, vector2 v2)
{
#if 0
  printf(" --- calculating adjustment maneuver for \n"
    "     s(%f,%f) v(%f,%f) onto\n"
    "     s2(%f,%f) v2(%f,%f)\n",
         s0.x,s0.y, v0.x,v0.y, s2.x,s2.y, v2.x,v2.y);
#endif

  vector2 gs0 = g(s0);
  vector2 gs2 = g(s2);
  vector2 s1 = (s0+s2)/2;

  for(int i=0;i<5;i++) {
    Dv1 = 0.25*(-3*gs0 - 2*g(s1) + gs2 - 6*v0 - 2*v2) - s0 + s2;
    Dv2 = 0.25*(gs0 - 2*g(s1) - 3*gs2 + 2*v0 + 6*v2) + s0 - s2;
    s1 = s0 + v0 + (gs0+Dv1)/2;
    //printf("[iter%d] Dv1:(%f,%f) Dv2:(%f,%f) s1:(%f,%f)\n", i, Dv1.x, Dv1.y, Dv2.x, Dv2.y, s1.x, s1.y);
  }
  return abs(Dv1)+abs(Dv2);
}

double min_adjust_maneuver(vector2 &Dv1, vector2 &Dv2, vector2 s0, vector2 v0, 
                           vector2 s2, vector2 v2, double radius)
{
  // need to stay within s2/v2 orbit
  double Dv;

  Dv = adjust_maneuver(Dv1, Dv2, s0, v0, s2, v2);
  printf("min_adjust: s2=(%f,%f) Dv=%f\n", s2.x, s2.y, Dv);

  vector2 gs0 = g(s0);
  vector2 gs2 = g(s2);
  vector2 s1 = (s0+s2)/2;

  // minimize the quantity Dv1^2+Dv2^2 s.t. |s2'-s2|<radius
  //
  // d/ds2 (Dv1^2+Dv2^2) = -2(g(s0)-g(s2)+2*(s0-s2+v0+v2))
  // d/dv2 (Dv1^2+Dv2^2) = 3g(s0)/2 - g(s1) - 5*g(s2)/2 + 4*s0 - 4*s2 + 3*v0 + 5*v2

  // calculate gradient vector and project it out towards radius
  vector2 Ds2 = -2*(g(s0)-g(s2)+2*(s0-s2+v0+v2));
  s2 = s2 - Ds2*radius/abs(Ds2);

  // iteratively solve for s1 and g(s1)
  for(int i=0;i<3;i++) {
    Dv1 = 0.25*(-3*gs0 - 2*g(s1) + gs2 - 6*v0 - 2*v2) - s0 + s2;
    Dv2 = 0.25*(gs0 - 2*g(s1) - 3*gs2 + 2*v0 + 6*v2) + s0 - s2;
    s1 = s0 + v0 + (gs0+Dv1)/2;
    //printf("[iter%d] Dv1:(%f,%f) Dv2:(%f,%f) s1:(%f,%f)\n", i, Dv1.x, Dv1.y, Dv2.x, Dv2.y, s1.x, s1.y);
  }
  Dv = abs(Dv1)+abs(Dv2);
  printf("min_adjust: s2'=(%f,%f) Dv=%f\n", s2.x, s2.y, Dv);

  return Dv;
}

// do a full correction of both position and velocity via two consecutive impulses
double orbit::transfer_maneuver(vector2 &Dv1, vector2 &Dv2, vector2 s0, vector2 v0, double radius) const
{
  // find the closest point on our orbit two timesteps after s0 and v0
  vector2 s1,v1, s2,v2;
  s1 = predict_s1(s0,v0,z2);
  v1 = predict_v1(s0,s1,z2);
  s2 = predict_s1(s1,v1,z2);
  // bump s2 onto our orbital radius
  s2 = position(true_anomaly(s2));
  // get the corrected velocity on the orbit at s2
  v2 = velocity(s2, v1);
  // calculate Dv1,Dv2,resultant s1, and iterate to refine approximation

  // TODO: minimize transfer delta-v numerically while staying on orbit
  // vector2 Ds2 = -2*(g(s0)-g(s2)+2*(s0-s2+v0+v2));

  return adjust_maneuver(Dv1, Dv2, s0, v0, s2, v2);
}

void test_orbit()
{
  double M = KeplerM(1.1, 0.75);
  double E = KeplerE(M, 0.75);
  printf("Kepler test (e=0.75): E=1.1 -> M=%f -> E=%f\n", M, E);
  M = KeplerM(1.1, 1);
  E = KeplerE(M, 1);
  printf("Kepler test (e=1): E=1.1 -> M=%f -> E=%f\n", M, E);

  orbit o(1000);
  vector2 v(0,1000);
  double nu = o.true_anomaly(v);
  printf("circular position -> anomaly: (0,1000) -> %f\n", nu);
  vector2 p = o.position(nu);
  printf("circular anomaly -> position: %f -> (%f,%f)\n", nu, p.x, p.y);
}

