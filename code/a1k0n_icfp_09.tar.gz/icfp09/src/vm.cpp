#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>

double   dmem[16384];
unsigned imem[16384];
double   iport[16384];
double   oport[16384];
int maxframe = 0;
bool status = false;

void read_obf(const char *fname)
{
  FILE *fp = fopen(fname, "rb");
  if(!fp) {
    printf("cannot open %s\n", fname);
    exit(-1);
  }

  memset(dmem, 0, sizeof(dmem));
  memset(imem, 0, sizeof(imem));
  memset(iport, 0, sizeof(iport));
  memset(oport, 0, sizeof(oport));

  unsigned char frame[12];
  double *d0   = (double*) &frame[0];
  unsigned *i0 = (unsigned*) &frame[8];
  double *d1   = (double*) &frame[4];
  unsigned *i1 = (unsigned*) &frame[0];
  int frameaddr = 0;
  while(fread(frame, 1, 12, fp) == 12) {
    if(frameaddr&1) {
      imem[frameaddr] = *i1;
      dmem[frameaddr] = *d1;
    } else {
      imem[frameaddr] = *i0;
      dmem[frameaddr] = *d0;
    }
    //printf("[%05x] %08x %f\n", frameaddr, imem[frameaddr], dmem[frameaddr]);
    frameaddr++;
  }
  maxframe = frameaddr;

  fclose(fp);
}

void vm_step(void)
{
  int ip;
  for(ip = 0;ip<maxframe;ip++) {
    unsigned insn = imem[ip];
    unsigned r1 = (insn>>14)&0x3fff;
    unsigned r2 = insn&0x3fff;
    //printf("%08x ", insn);
    switch(insn>>28) {
      case 0: // s-instr
        {
          unsigned op = (insn>>24)&0x0f;
          unsigned imm = (insn>>21)&0x07;
          r1 = r2;
          switch(op) {
            case 0: // noop
              //printf("# noop [%04x] = %f\n", ip, dmem[ip]);
              break;
            case 1: // cmpz
              switch(imm) {
                case 0: // ltz
                  status = dmem[r1] < 0;
                  //printf("status=%d <- [%04x]=%f < 0\n", status?1:0, r1, dmem[r1]);
                  break;
                case 1: // lez
                  status = dmem[r1] <= 0;
                  //printf("status=%d <- [%04x]=%f <= 0\n", status?1:0, r1, dmem[r1]);
                  break;
                case 2: // eqz
                  status = dmem[r1] == 0;
                  //printf("status=%d <- [%04x]=%f == 0\n", status?1:0, r1, dmem[r1]);
                  break;
                case 3: // gez
                  status = dmem[r1] >= 0;
                  //printf("status=%d <- [%04x]=%f >= 0\n", status?1:0, r1, dmem[r1]);
                  break;
                case 4: // gtz
                  status = dmem[r1] > 0;
                  //printf("status=%d <- [%04x]=%f > 0\n", status?1:0, r1, dmem[r1]);
                  break;
                default: printf("DECODING BUG: cmpz op %d?\n", imm);
              }
              break;
            case 2: // sqrt
              //assert(dmem[r1] >= 0);
              dmem[ip] = sqrt(dmem[r1]);
              //printf("[%04x]=%f <- sqrt([%04x]=%f)\n", ip, dmem[ip], r1, dmem[r1]);
              break;
            case 3: // copy
              dmem[ip] = dmem[r1];
              //printf("[%04x]=%f <- [%04x]=%f\n", ip, dmem[ip], r1, dmem[r1]);
              break;
            case 4: // input
              dmem[ip] = iport[r1];
              //printf("[%04x] <- iport[%04x]=%f\n", ip, r1, iport[r1]);
              break;
            default: printf("DECODING BUG: S-instr op %d?\n", op);
          }
        }
        break;
      case 1: // add 
        dmem[ip] = dmem[r1] + dmem[r2];
        //printf("[%04x]=%f <- [%04x]=%f + [%04x]=%f\n", ip, dmem[ip], r1, dmem[r1], r2, dmem[r2]);
        break;
      case 2: // sub
        dmem[ip] = dmem[r1] - dmem[r2];
        //printf("[%04x]=%f <- [%04x]=%f - [%04x]=%f\n", ip, dmem[ip], r1, dmem[r1], r2, dmem[r2]);
        break;
      case 3: // mult 
        dmem[ip] = dmem[r1] * dmem[r2];
        //printf("[%04x]=%f <- [%04x]=%f * [%04x]=%f\n", ip, dmem[ip], r1, dmem[r1], r2, dmem[r2]);
        break;
      case 4: // div
        if(dmem[r2] == 0) dmem[ip] = 0;
        else dmem[ip] = dmem[r1] / dmem[r2];
        //printf("[%04x]=%f <- [%04x]=%f / [%04x]=%f\n", ip, dmem[ip], r1, dmem[r1], r2, dmem[r2]);
        break;
      case 5: // output
        oport[r1] = dmem[r2];
        //printf("out[%04x] <- [%04x]=%f\n", r1, r2, dmem[r2]);
        break;
      case 6: // phi (cmov)
        dmem[ip] = status ? dmem[r1] : dmem[r2];
        //printf("[%04x]=%f <- status=%d ? [%04x]=%f : [%04x]=%f\n", ip, dmem[ip],
        //       status?1:0, r1, dmem[r1], r2, dmem[r2]);
        break;
      default: printf("DECODING BUG: D-instr op %d?\n", insn>>28);
    }
  }
}


