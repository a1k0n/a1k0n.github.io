#include <math.h>

const double Gme = 4.004568e14;

struct vector2
{
  double x,y;

  vector2() {}
  vector2(double _x, double _y) { x=_x; y=_y; }
  vector2 operator+(const vector2 &b) const { return vector2(x+b.x, y+b.y); }
  vector2 operator-(const vector2 &b) const { return vector2(x-b.x, y-b.y); }
  vector2 operator-() const { return vector2(-x, -y); }
  double operator*(const vector2 &b) const { return x*b.x + y*b.y; } // dot product
};

static const vector2 z2(0,0);

static inline vector2 operator*(vector2 v, double s) { return vector2(s*v.x,s*v.y); } // scalar product
static inline vector2 operator*(double s, vector2 v) { return vector2(s*v.x,s*v.y); } // scalar product

static inline vector2 operator/(vector2 v, double s) { return vector2(v.x/s,v.y/s); } // scalar quotient

// cross product of vectors in two space returns a scalar z-axis "vector"
static inline double operator%(const vector2 &a, const vector2 &b) { return a.x*b.y - a.y*b.x; }

// cross products with scalars presumed to be vectors along z-axis
static inline vector2 operator%(double a, const vector2 &b) { return vector2(-a*b.y, a*b.x); }
static inline vector2 operator%(const vector2 &a, double b) { return vector2(a.y*b, -a.x*b); }

static inline double abs(const vector2 &v) { return sqrt(v.x*v.x+v.y*v.y); }

struct trajectory
{
  vector2 r, v;

  trajectory() {}
  trajectory(const vector2 &_r, const vector2 &_v) { r=_r; v=_v; }
};

struct orbit
{
  vector2 e; // eccentricity vector
  double emag; // eccentricity magnitude
  double h; // specific relative angular momentum
  double p; // semi-latus rectum (p = h^2/Gme)
  double a; // semi-major axis

  orbit() {}
  orbit(double radius); // circular orbit
  orbit(vector2 r0, double r1); // Hohmann transfer orbit

  void print() const { printf("e(%f,%f) p(%f) a(%f) h(%f)", e.x,e.y, p, a, h); }

  // get orbital velocity vector at point r (presumed to lie on the orbit
  // already) in the same direction of current velocity cur_v
  vector2 velocity(vector2 r, vector2 cur_v) const;
  double period() const { return sqrt(4*M_PI*M_PI*a*a*a/Gme); }
  // get true anomaly angle from arbitrary vector
  double true_anomaly(vector2 r) const {
    if(emag < 1e-6) {
      return atan2(r.y, r.x);
    }
    vector2 ehat = e/emag;
    vector2 econj = 1%ehat;
    //printf("ehat: (%f,%f) econj (%f,%f)\n", ehat.x, ehat.y, econj.x, econj.y);
    return atan2(r*econj, r*ehat);
  }
  // world position of orbit given true anomaly
  vector2 position(double nu) const {
    if(emag < 1e-6) {
      return p*vector2(cos(nu), sin(nu));
    }
    vector2 ehat = e/emag;
    vector2 econj = 1%ehat;
    double cnu = cos(nu), snu = sin(nu);
    double r = p/(1+emag*cnu);
    return ehat*cnu*r + econj*snu*r;
  }

  double radius(double nu) const { return p/(1+emag*cos(nu)); }

  // project the orbit forward in time starting at position r0
  vector2 project_forward(vector2 r0, double t) const;
  double forward_angle(double nu, double t) const;

  // return the total amount of delta-V required to transfer onto this orbit
  // (correcting both position and velocity) at the given position and velocity
  // of some other orbit
  double transfer_maneuver(vector2 &Dv1, vector2 &Dv2, vector2 s0, vector2 v0, double radius) const;
};

extern orbit calc_orbit(double &nu, trajectory t);

// find the next time at which we can initiate a hohmann transfer orbit from
// orbit o1 (at angle o1nu) onto orbit o2 (at angle o2nu)
extern double next_transfer_time(double &destnu, double &srcnu, const orbit &o1, double o1nu, const orbit &o2, double o2nu);
extern double adjust_maneuver(vector2 &Dv1, vector2 &Dv2, vector2 s0, vector2 v0, vector2 s2, vector2 v2);
extern double min_adjust_maneuver(vector2 &minDv1, vector2 &minDv2, vector2 s0, vector2 v0, 
                                  vector2 s2, vector2 v2, double radius);

// calculate transfer orbit onto orbit o from current position r
//extern orbit calc_transfer(orbit o, vector2 r);

// calculate amount of time it would take to reach orbit o on a transfer orbit starting at r
extern double transfer_time(const orbit &o, vector2 r);
// and the location where would end up
extern vector2 transfer_dest(const orbit &o, vector2 r);

extern double KeplerE(double M);
extern double KeplerM(double E);

extern void test_orbit();

static inline vector2 g(vector2 r)
{
  double R = abs(r);
  return -Gme*r/(R*R*R);
}


// predict current velocity from last two measurements (s1 being most current)
// (assumes no impulses)
static inline vector2 predict_v1(vector2 s0, vector2 s1, vector2 Dv)
{
  // calculate velocity from the previous frame
  vector2 v0 = s1 - s0 - (g(s0)+Dv)/2;
  return v0 + Dv + (g(s0)+g(s1))/2;
}

// predict next position from current position and velocity
// (assumes no impulses)
static inline vector2 predict_s1(vector2 s0, vector2 v0, vector2 Dv)
{
  return s0 + v0 + (g(s0)+Dv)/2;
}

static inline vector2 thrust_vector(vector2 cur_s, vector2 cur_v, vector2 desired_v)
{
  vector2 next_s = predict_s1(cur_s, cur_v, z2);
  vector2 Dv = desired_v - cur_v - (g(cur_s) + g(next_s))/2;
  // iterate to refine impulse estimate
  printf("thrust initial guess: (%f,%f) (%f,%f)\n", next_s.x, next_s.y, Dv.x, Dv.y);
  for(int i=0;i<3;i++) {
    next_s = predict_s1(cur_s, cur_v, Dv);
    Dv = desired_v - cur_v - (g(cur_s) + g(next_s))/2;
    printf("thrust refine %d: (%f,%f) (%f,%f)\n", i, next_s.x, next_s.y, Dv.x, Dv.y);
  }
  return Dv;
}

