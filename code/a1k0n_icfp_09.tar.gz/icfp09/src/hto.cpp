// hohmann transfer orbit
// with a twist: waste as much fuel as you can without going over
#include "vm.h"
#include "osf.h"
#include "orbit.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

unsigned scenario = 1001;

int timestep = 0;

vector2 sim_step(vector2 thrust, bool do_print = false)
{
  if(timestep < 10 || timestep%1000 == 0) do_print = true;
  osf_thrust(timestep, thrust.x, thrust.y);
  vm_step();
  timestep++;
  static vector2 last_s(0,0);
  vector2 s(oport[2], oport[3]);
  if(do_print) {
    printf("---step %d\n", timestep);
    printf("score : %f\n", oport[0]);
    printf("fuel  : %f\n", oport[1]);
    printf("target: %f\n", oport[4]);
    printf("s%d = (%f,%f)\n", timestep, s.x, s.y);
    printf("r%d = %f\n", timestep, abs(s));
    if(timestep > 1) {
      vector2 v = predict_v1(last_s, s, thrust);
      printf("v%d = (%f,%f)\n", timestep, v.x, v.y);
    }
  }
  last_s = s;
  // are we done?
  if(oport[0] != 0) {
    printf("done at step %d, score = %f\n", timestep, oport[0]);
    close_osf(timestep);
    exit(0);
  }
  return s;
}


int main(int argc, char **argv)
{
  if(argc < 4) {
    printf("usage: %s <bin1.obf> <scenario> <output.osf>\n", argv[0]);
    return 0;
  }

  read_obf(argv[1]);
  open_osf(argv[3], atoi(argv[2]));

  vector2 s1 = sim_step(z2,true);
  vector2 s2 = sim_step(z2,true);
  vector2 v2 = predict_v1(s1,s2,z2);

  double target_radius = oport[4];

  double cosnu;
  orbit present = calc_orbit(cosnu, trajectory(s2,v2));
  printf("present trajectory: r=(%f,%f) v=(%f,%f)\n", s2.x, s2.y, v2.x, v2.y);
  printf("present orbit: cosnu=%f; ", cosnu); present.print(); printf("\n");

  orbit final = orbit(target_radius);
  printf("final orbit: "); final.print(); printf("\n");
  orbit transfer = orbit(s2, target_radius);
  printf("transfer orbit: "); transfer.print(); printf("\n");

  vector2 tv = transfer.velocity(s2, v2);
  printf("transfer velocity at s%d: (%f,%f)\n", timestep, tv.x, tv.y);
  sim_step(thrust_vector(s2, v2, tv), true);

  // doot de doo, fly through a half-period of our transfer orbit
  for(;;) {
    s1 = sim_step(z2, false);
    if(abs(s1) > target_radius) break;
  }

  s2 = sim_step(z2, true);
  v2 = predict_v1(s1,s2,z2);
  printf("radius should be %f\n", target_radius);
  printf("present trajectory: r=(%f,%f) v=(%f,%f)\n", s2.x, s2.y, v2.x, v2.y);
  present = calc_orbit(cosnu, trajectory(s2,v2));
  printf("present orbit: cosnu=%f; ", cosnu); present.print(); printf("\n");

  tv = final.velocity(s2, v2);
  printf("final velocity at s%d: (%f,%f)\n", timestep, tv.x, tv.y);

  sim_step(thrust_vector(s2, v2, tv), true);
  s1 = sim_step(z2, true);
  s2 = sim_step(z2, true);
  v2 = predict_v1(s1,s2,z2);
  present = calc_orbit(cosnu, trajectory(s2,v2));
  printf("final orbit: cosnu=%f; ", cosnu); present.print(); printf("\n");

  // waste fuel till we're out and then wait for exit
  printf("spending remaining fuel\n");
  s2 = sim_step((oport[1]/2)*s2/abs(s2), true);
  sim_step(-(oport[1])*s2/abs(s2), true);
  for(;;) {
    sim_step(z2, false);
  }
}

