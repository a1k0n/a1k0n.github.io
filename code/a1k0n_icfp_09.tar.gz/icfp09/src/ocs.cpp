// operation clear skies
#include "vm.h"
#include "osf.h"
#include "orbit.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static int timestep = 0;
static vector2 s_(0,0), s, v; // s_ is the previous frame's position
static vector2 target_[12], target[12], targetv[12]; // target 0 is the refuelling station
static vector2 moon;
int sat_to_visit = -1;

void sim_step(vector2 thrust, bool do_print = false)
{
//  if(timestep < 3 || timestep%1000 == 0) do_print = true;
  osf_thrust(timestep, thrust.x, thrust.y);

  if(thrust.x != 0 || thrust.y != 0)
    printf("impulse @t%d: (%f,%f)\n", timestep, thrust.x, thrust.y);

  vm_step();
  timestep++;
  s_ = s;
  s = vector2(oport[2], oport[3]);
  v = predict_v1(s_, s, thrust);
  for(int i=0;i<12;i++) {
    target_[i] = target[i];
    target[i] = s - vector2(oport[3*i+4], oport[3*i+5]);
    targetv[i] = predict_v1(target_[i], target[i], z2);
  }
  moon = s - vector2(oport[0x64], oport[0x65]);

  if(do_print) {
    printf("---step %d\n", timestep);
    printf("score : %f\n", oport[0]);
    printf("fuel  : %f\n", oport[1]);
    printf("s%d = (%f,%f)\n", timestep, s.x, s.y);
    printf("moon = (%f,%f)\n", moon.x, moon.y);
    if(timestep > 1) {
      printf("v%d = (%f,%f)\n", timestep, v.x, v.y);
      double nu;
      orbit o = calc_orbit(nu, trajectory(s,v));
      printf("our orbit: nu=%f; ", nu); o.print(); printf("\n");
      if(sat_to_visit) {
        printf("sat%d: dist=%f; r(%f,%f) v(%f,%f)\n", sat_to_visit,
               abs(target[sat_to_visit] - s),
               target[sat_to_visit].x, target[sat_to_visit].y,
               targetv[sat_to_visit].x, targetv[sat_to_visit].y);
        orbit o = calc_orbit(nu, trajectory(target[sat_to_visit],targetv[sat_to_visit]));
        printf("sat%d orbit: nu=%f; ", sat_to_visit, nu); o.print(); printf("\n");
      }
    }
  }
  // are we done?
  if(oport[0] != 0) {
    printf("done at step %d, score = %f\n", timestep, oport[0]);
    close_osf(timestep);
    exit(0);
  }
} 

void intercept_target(double meet_time, int i)
{
  while(timestep < meet_time-4) sim_step(z2, false);
  // project forward in time, find minimum delta v timestep

  vector2 Dv1, Dv2;
  int min_i=0;
  double min_Dv=0;

  vector2 s0=s, v0=v, ts0=target[i], tv0=targetv[i];
  vector2 s1,v1, ts1,tv1, ts2,tv2;
  s1 = predict_s1(s0,v0,z2); v1 = predict_v1(s0,s1,z2);
  ts1 = predict_s1(ts0,tv0,z2); tv1 = predict_v1(ts0,ts1,z2);
  ts2 = predict_s1(ts1,tv1,z2); tv2 = predict_v1(ts1,ts2,z2);

  for(int i=0;;i++) {
    vector2 Dv1_,Dv2_;
    double Dv = min_adjust_maneuver(Dv1_,Dv2_,s0,v0, ts2,tv2, 999);

    if(abs(s1-ts1) < 1000) { // freebie; we hit it
      Dv = 0; Dv1_ = z2; Dv2_ = z2;
    }

    printf("intercept @t=%d; Dv=%f\n", timestep+i, Dv);
    if(i==0 || Dv < min_Dv) { min_i = i; min_Dv = Dv; Dv1=Dv1_; Dv2=Dv2_; }
    else break;
    s0=s1; v0=v1;
    s1 = predict_s1(s0,v0,z2); v1 = predict_v1(s0,s1,z2);
    ts1=ts2; tv1=tv2;
    ts2 = predict_s1(ts1,tv1,z2); tv2 = predict_v1(ts1,ts2,z2);
  }
  for(int j=0;j<min_i;j++) sim_step(z2, j > min_i - 2);

  if(oport[1] < min_Dv) {
    printf("out of fuel; does this score anything?\n");
    for(;;) { sim_step(z2, false); }
    //close_osf(timestep);
    //exit(0);
  }
  sim_step(Dv1, true);
  sim_step(Dv2, true);
}

void transfer_orbit(const orbit &o, double transfer_time)
{
  double nu;
  vector2 Dv1(0,0), Dv2(0,0);

#if 0
  // just wait out until our time hint
  while(timestep < transfer_time-2) sim_step(z2, timestep > transfer_time - 4);

  o.transfer_maneuver(Dv1, Dv2, s, v);

#else
  while(timestep < transfer_time-20) sim_step(z2, false);
  // now, project forward in time and find the minimum transfer fuel
  double min_Dv=0;
  vector2 fs=s, fv=v; // forward position and velocity
  int min_i=0;
  // just assume that total delta-v is going to decrease over time, then increase again
  // (as long as our time projection isn't totally hosed that should be true)
  for(int i=0;;i++) {
    vector2 v1, v2;
    double Dv = o.transfer_maneuver(v1, v2, fs, fv, 0);
    printf("t=%d Dv=%f s=(%f,%f) v=(%f,%f)\n", timestep+i, Dv, fs.x, fs.y, fv.x, fv.y);
    if(i==0 || Dv < min_Dv) { Dv1 = v1; Dv2 = v2; min_Dv = Dv; min_i = i; }
    else break;
    vector2 fs_ = predict_s1(fs, fv, z2);
    fv = predict_v1(fs, fs_, z2);
    fs = fs_;
  }

  for(int j=0;j<min_i;j++) sim_step(z2, j > (min_i - 3));
#endif

  printf(" --- initiating orbital transfer @t=%d to desired orbit:\n", timestep);
  o.print(); printf("\n");

  printf("s%d = (%f,%f)\n", timestep, s.x, s.y);
  printf("v%d = (%f,%f)\n", timestep, v.x, v.y);

  orbit present = calc_orbit(nu, trajectory(s,v));
  printf("initial orbit: nu=%f; ", nu); present.print(); printf("\n");

  if(oport[1] < min_Dv) {
    printf("out of fuel; does this score anything?\n");
    for(;;) { sim_step(z2, false); }
    //close_osf(timestep);
    //exit(0);
  }
  printf("executing maneuver V1(%f,%f) V2(%f,%f)\n", Dv1.x, Dv1.y, Dv2.x, Dv2.y);
  sim_step(Dv1, true);
  sim_step(Dv2, true);

  present = calc_orbit(nu, trajectory(s,v));
  printf("final orbit: nu=%f; ", nu); present.print(); printf("\n");
  printf(" --- orbital transfer completed @t=%d\n", timestep);
}


int main(int argc, char **argv)
{
  if(argc < 4) {
    printf("usage: %s <bin4.obf> <scenario> <output.osf>\n", argv[0]);
    return 0;
  }

  read_obf(argv[1]);
  open_osf(argv[3], atoi(argv[2]));

  sim_step(z2,true);
  sim_step(z2,true);

  double nu;
  orbit present = calc_orbit(nu, trajectory(s,v));
  //printf("present trajectory: r=(%f,%f) v=(%f,%f)\n", s.x, s.y, v.x, v.y);
  //printf("present orbit: nu=%f; ", nu); present.print(); printf("\n");

  orbit target_orbit[12];
  for(int i=0;i<12;i++) {
    target_orbit[i] = calc_orbit(nu, trajectory(target[i],targetv[i]));
    printf("target %d trajectory: r=(%f,%f) v=(%f,%f)\n", i, target[i].x, target[i].y, target[i].x, target[i].y);
    printf("target %d orbit: nu=%f; ", i, nu); target_orbit[i].print(); printf("\n");
  }

  // greedy method: just hit the unvisited satellites as soon as you can
  for(sat_to_visit=1;sat_to_visit<12;sat_to_visit++) {
    //sat_to_visit = -1;
    orbit ideal_transfer;
#if 1
    double t;
    double Dvmin;
    for(int i=1;i<12;i++) {
      if(oport[3*i+6] > 0) continue; // already collected
      double t_;
      double nu0, nu1;
      t_ = timestep + next_transfer_time(nu1, nu0, present, present.true_anomaly(s), 
                                         target_orbit[i], target_orbit[i].true_anomaly(target[i]));
      // calculate ideal delta-V
      double r1 = present.radius(nu0);
      double r2 = target_orbit[i].radius(nu1);
      double Dv = sqrt(Gme/r1)*(sqrt(2*r2/(r1+r2))-1) + sqrt(Gme/r2)*(1-sqrt(2*r1/(r1+r2)));
      printf("sat %d next closest approach @%f, nu@o1 = %f, nu@o2 = %f Dv=%f\n", i, t_, nu0, nu1, Dv);

      if(i == 1 || Dv < Dvmin && t_ < 2e6) {
        sat_to_visit = i;
        t = t_;
        ideal_transfer = orbit(present.position(nu0), target_orbit[i].radius(nu1));
      }
    }
#else
    double t;
    double nu0, nu1;
    int i = sat_to_visit;
    t = timestep + next_transfer_time(nu1, nu0, present, present.true_anomaly(s), 
                                      target_orbit[i], target_orbit[i].true_anomaly(target[i]));
    printf("sat %d next closest approach @%f, nu@o1 = %f, nu@o2 = %f\n", i, t, nu0, nu1);

    if(t >= 2e6)
      continue;
    ideal_transfer = orbit(present.position(nu0), target_orbit[i].radius(nu1));
#endif
    if(sat_to_visit == -1)
      break;
    printf(" *** visiting satellite %d @%f\n", sat_to_visit, t);
    // transfer onto our transfer orbit
    transfer_orbit(ideal_transfer, t);
    intercept_target(t + ideal_transfer.period()/2, sat_to_visit);
    // TODO: instead of intercepting, touch the satellite on the way to the next transfer orbit
  }

#if 0
  // now!  we can project forward in time and see where the target satellite
  // would be if we were to do a Hormann transfer onto its orbit from our
  // present location, and then determine if we are ahead of or behind it, and
  // bisect to find the optimal time to catch it.  or we can just poll for a
  // suitable time to transfer.

  double t;
  double nu0, nu1;
  t = timestep + next_transfer_time(nu1, nu0, present, present.true_anomaly(s), 
                                    target_orbit, target_orbit.true_anomaly(target));
  printf("next closest approach @%f, nu@o1 = %f, nu@o2 = %f\n", t, nu0, nu1);

  orbit ideal_transfer(present.position(nu0), target_orbit.radius(nu1));

  {
    vector2 sproj = present.position(nu0);
    vector2 vproj = present.velocity(sproj, z2);
    printf("projected sat trajectory at transfer t%f: s(%f,%f) v(%f,%f)\n", t,
           sproj.x, sproj.y, vproj.x, vproj.y);
    sproj = target_orbit.position(nu1);
    vproj = target_orbit.velocity(sproj, z2);
    printf("projected target trajectory at meet t%f: s(%f,%f) v(%f,%f)\n", t + ideal_transfer.period()/2,
           sproj.x, sproj.y, vproj.x, vproj.y);
  }

  // transfer onto our transfer orbit
  transfer_orbit(ideal_transfer, t);
  // transfer onto the target orbit
//  hold_orbit(ideal_transfer, t + ideal_transfer.period()/2 - 20);
  //transfer_orbit(target_orbit, t + ideal_transfer.period()/2);
  intercept_target(t + ideal_transfer.period()/2, 999);


  // and run it through to win (maybe)
  for(int i=0;i<3000;i++) { sim_step(z2, false); }
#endif
}

