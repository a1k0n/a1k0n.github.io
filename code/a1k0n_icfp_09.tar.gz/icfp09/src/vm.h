extern double   dmem[16384];
extern unsigned imem[16384];
extern double   iport[16384];
extern double   oport[16384];
extern bool status;

extern void read_obf(const char *fname);
extern void vm_step(void);

