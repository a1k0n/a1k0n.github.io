#include "expr.h"

expression::~expression() {}

static int _spill_id=0;
void expression::spill(std::ostream &o) {
  if(ref > 1 && id == -1) {
    o << "double _" << _spill_id << " = " << this << ";\n  ";
    id = _spill_id++;
  }
}

std::ostream& operator<<(std::ostream &o, expression *e)
{
  if(e->id != -1) {
    o << "_" << e->id;
  } else {
    e->to_stream(o);
  }
  return o;
}

// default comparisons
int expression::eqz(void) const { return val().eqz(); }
int expression::gtz(void) const { return val().gtz(); }
int expression::ltz(void) const { return val().ltz(); }
int expression::gez(void) const { return val().gez(); }
int expression::lez(void) const { return val().lez(); }

bool expression::is_const(void) const { return val().is_const(); }

struct expr_const: public expression
{
  double value;

  expr_const(double v) { value = v; }
  virtual ~expr_const() {}

  virtual bool is_const() const { return true; }
  virtual value_range val() const { return value_range(value, value); }
  virtual void to_stream(std::ostream &o) const { o << value; }
  virtual int oporder(void) const { return 0; }
  virtual void spill(std::ostream &o) {}
};

struct expr_add: public expression
{
  expression *lhs, *rhs;

  expr_add(expression *l, expression *r) { lhs = l; rhs = r; l->ref++; r->ref++; }
  virtual ~expr_add() { lhs->ref--; rhs->ref--; }
  virtual value_range val() const { return lhs->val() + rhs->val(); }
  virtual void to_stream(std::ostream &o) const {
    if(lhs->oporder() > oporder()) o << "(" << lhs << ")";
    else o << lhs;
    o << " + ";
    if(rhs->oporder() > oporder()) o << "(" << rhs << ")";
    else o << rhs;
  }

  virtual int oporder(void) const { return id==-1 ? 4 : 0; }
  virtual void spill(std::ostream &o) { lhs->spill(o); rhs->spill(o); expression::spill(o); }
};

struct expr_sub: public expression
{
  expression *lhs, *rhs;

  expr_sub(expression *l, expression *r) { lhs = l; rhs = r; l->ref++; r->ref++; }
  virtual ~expr_sub() { lhs->ref--; rhs->ref--; }
  virtual value_range val() const { return lhs->val() - rhs->val(); }
  virtual void to_stream(std::ostream &o) const {
    if(lhs->oporder() > oporder()) o << "(" << lhs << ")";
    else o << lhs;
    o << " - ";
    if(rhs->oporder() >= oporder()) o << "(" << rhs << ")";
    else o << rhs;
  }

  virtual int oporder(void) const { return id==-1 ? 3 : 0; }
  virtual void spill(std::ostream &o) { lhs->spill(o); rhs->spill(o); expression::spill(o); }
};

struct expr_mul: public expression
{
  expression *lhs, *rhs;

  expr_mul(expression *l, expression *r) { lhs = l; rhs = r; l->ref++; r->ref++; }
  virtual ~expr_mul() { lhs->ref--; rhs->ref--; }
  virtual value_range val() const { return lhs->val() * rhs->val(); }
  virtual void to_stream(std::ostream &o) const {
    if(lhs->oporder() > oporder()) o << "(" << lhs << ")";
    else o << lhs;
    o << " * ";
    if(rhs->oporder() > oporder()) o << "(" << rhs << ")";
    else o << rhs;
  }

  virtual int oporder(void) const { return id==-1 ? 2 : 0; }
  virtual void spill(std::ostream &o) { lhs->spill(o); rhs->spill(o); expression::spill(o); }
};

struct expr_div: public expression
{
  expression *lhs, *rhs;

  expr_div(expression *l, expression *r) { lhs = l; rhs = r; l->ref++; r->ref++; }
  virtual ~expr_div() { lhs->ref--; rhs->ref--; }
  virtual value_range val() const { return lhs->val() / rhs->val(); }
  virtual void to_stream(std::ostream &o) const {
    if(lhs->oporder() > oporder()) o << "(" << lhs << ")";
    else o << lhs;
    o << " / ";
    if(rhs->oporder() >= oporder()) o << "(" << rhs << ")";
    else o << rhs;
  }

  virtual int oporder(void) const { return id==-1 ? 1 : 0; }
  virtual void spill(std::ostream &o) { lhs->spill(o); rhs->spill(o); expression::spill(o); }
};

struct expr_sqrt: public expression
{
  expression *arg;

  expr_sqrt(expression *a) { arg=a; a->ref++; }
  virtual ~expr_sqrt() { arg->ref--; }
  virtual value_range val() const { return value_range(0, INFINITY); }
  virtual void to_stream(std::ostream &o) const {
    o << "sqrt(" << arg << ")";
  }

  virtual int oporder(void) const { return 0; }
  virtual void spill(std::ostream &o) { arg->spill(o); expression::spill(o); }
};

struct expr_ref: public expression
{
  int addr;
  int type; // 0 = state, 1 = input
  value_range v;

  expr_ref(int _addr, int t, value_range _v) { addr=_addr; type=t; v=_v; }
  virtual ~expr_ref() { }
  virtual value_range val() const { return v; }
  virtual void to_stream(std::ostream &o) const {
    if(type == 1)
      o << "input[" << addr << "]";
    else
      o << "s->d" << addr;
  }

  virtual int oporder(void) const { return 0; }
  virtual void spill(std::ostream &o) { }
};

static const char *cmptypes[5] = {"<","<=","==",">=",">"};
// arg is assumed to be not constant, otherwise expr_cmpz would not be generated
struct expr_cmpz: public expression
{
  expression *arg;
  int subtype;

  expr_cmpz(expression *a, int ctype) { arg=a; subtype=ctype; a->ref++; }
  virtual ~expr_cmpz() { arg->ref--; }
  virtual value_range val() const { return value_range(0,1); }

  virtual void to_stream(std::ostream &o) const {
    o << arg << " " << cmptypes[subtype] << " 0";
  }
  virtual int oporder(void) const { return id==-1 ? 10 : 0; }
  virtual void spill(std::ostream &o) { arg->spill(o); expression::spill(o); }
};

// assume that cmp is not constant here, otherwise expr_phi would not be
// generated by gen_phi
struct expr_phi: public expression
{
  expression *cmp, *a, *b;

  expr_phi(expression *c, expression *t, expression *f) { 
    cmp = c; a = t; b = f; 
    cmp->ref++; a->ref++; b->ref++;
  }
  virtual ~expr_phi() { }
  virtual value_range val() const { return value_range(a->val(), b->val()); }
  virtual void to_stream(std::ostream &o) const {
    o << cmp << " ? " << a << " : " << b;
  }

  virtual int oporder(void) const { return id==-1 ? 11 : 0; }
  virtual void spill(std::ostream &o) { cmp->spill(o); a->spill(o); b->spill(o); expression::spill(o); }
};

// ------------------

expression *gen_const(double c) { return new expr_const(c); }

expression *gen_add(expression *a, expression *b) {
  if(a->is_const() && b->is_const()) return new expr_const(a->val().min + b->val().min);
  if(a->is_const() && a->val().min == 0) return b;
  if(b->is_const() && b->val().min == 0) return a;
  return new expr_add(a, b);
}

expression *gen_sub(expression *a, expression *b) {
  if(a->is_const() && b->is_const()) return new expr_const(a->val().min - b->val().min);
  if(b->is_const() && b->val().min == 0) return a;
  return new expr_sub(a, b);
}

expression *gen_mul(expression *a, expression *b) {
  if(a->is_const() && b->is_const()) return new expr_const(a->val().min * b->val().min);
  if(a->is_const() && a->val().min == 0) return new expr_const(0);
  if(b->is_const() && b->val().min == 0) return new expr_const(0);
  if(a->is_const() && a->val().min == 1) return b;
  if(b->is_const() && b->val().min == 1) return a;
  return new expr_mul(a, b);
}

expression *gen_div(expression *a, expression *b) {
  if(a->is_const() && b->is_const()) return new expr_const(a->val().min / b->val().min);
  if(a->is_const() && a->val().min == 0) return new expr_const(0);
  if(b->is_const() && b->val().min == 1) return a;
  return new expr_div(a, b);
}

expression *gen_sqrt(expression *a) {
  if(a->is_const()) return new expr_const(sqrt(a->val().min));
  return new expr_sqrt(a);
}

expression *gen_cmpz(expression *a, int cmptype)
{
  int z=-1;
  switch(cmptype) {
    case 0: z = a->ltz(); break;
    case 1: z = a->lez(); break;
    case 2: z = a->eqz(); break;
    case 3: z = a->gez(); break;
    case 4: z = a->gtz(); break;
  }
  if(z == -1) 
    return new expr_cmpz(a, cmptype);
  return new expr_const(z);
}

expression *gen_phi(expression *cmp, expression *t, expression *f)
{
  if(cmp->is_const()) { return cmp->val().min ? t : f; }
  return new expr_phi(cmp, t, f);
}

expression *gen_ref(int addr, int type, value_range v)
{
  return new expr_ref(addr, type, v);
}

