#include <stdio.h>
#include <stdlib.h>
#include "vm.h"
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
  if(argc < 3) {
    printf("usage: %s <obf> <scenario>\n", argv[0]);
    return -1;
  }

  read_obf(argv[1]);
  //vm_dump_consts();
  vm_dump_forwardrefs();

  cout << "#include <math.h>\n\n"
    "void vm_init(vm_state *s, double *output, double *input) {\n  ";
  vm_dump(0, atoi(argv[2]));
  cout << "\n}\n\n";

  cout << "void vm_step(vm_state *s, double *output, double *input) {\n  ";
  vm_dump(1, atoi(argv[2]));
  cout << "\n}\n\n";

  return 0;
}
