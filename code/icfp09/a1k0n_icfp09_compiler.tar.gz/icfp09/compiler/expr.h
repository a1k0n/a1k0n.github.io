#include "range.h"
#include <ostream>
#include <string>

struct expression
{
  int ref; // reference count
  int id;

  // subclasses must provide:
  expression() { ref=0; id=-1; };
  virtual ~expression()=0; // destructor
  virtual value_range val() const=0; // possible value range
  virtual void to_stream(std::ostream &o) const=0; // C representation

  virtual int oporder(void) const=0;

  // true if expression is a constant
  virtual bool is_const() const;

  // returns 1 if definitely true, 0 if definitely false, -1 if unknown
  virtual int eqz(void) const;
  virtual int gtz(void) const;
  virtual int ltz(void) const;
  virtual int gez(void) const;
  virtual int lez(void) const;

  virtual void spill(std::ostream &o);
};

extern std::ostream& operator<<(std::ostream &o, expression *e);

expression *gen_const(double c);
expression *gen_add(expression *a, expression *b);
expression *gen_sub(expression *a, expression *b);
expression *gen_mul(expression *a, expression *b);
expression *gen_div(expression *a, expression *b);
expression *gen_sqrt(expression *a);

expression *gen_cmpz(expression *a, int cmptype);
expression *gen_phi(expression *cmp, expression *a, expression *b);

expression *gen_ref(int addr, int type, value_range v);

