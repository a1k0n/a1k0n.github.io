extern double iport[16384];
extern double oport[16384];

struct instruction
{
  unsigned instr;
  enum { Noop, Cmpz, Input, Output, ALU1, ALU2, Phi } type;
  int subtype;
  int r1, r2;
  double data;
  instruction() {}
  instruction(unsigned insn, double d);
};

extern void read_obf(const char *fname);

extern void vm_step(void);
extern void vm_dump_consts(void);
extern void vm_dump_forwardrefs(void);
extern void vm_dump(int pass, int scenario);

