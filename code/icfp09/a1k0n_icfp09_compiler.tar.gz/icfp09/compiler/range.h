#ifndef __RANGE_H
#define __RANGE_H

#include <math.h>

struct value_range
{
  double min, max;

  value_range() { min=-INFINITY, max=INFINITY; }
  value_range(double x) { min = max = x; }
  value_range(double _min, double _max) { min=_min; max=_max; }
  value_range(const value_range &a, const value_range &b) {
    min = fmin(a.min, b.min);
    max = fmax(a.max, b.max);
  }

  value_range checkswap(void) { if(min > max) { double t = min; min = max; max = t; } return *this; }

  bool is_const(void) const { return min == max; }
  int eqz(void) const {
    if(min > 0) return 0;
    if(max < 0) return 0;
    if(min == 0 && max == 0) return 1;
    return -1;
  }
  int gez(void) const {
    if(min >= 0) return 1;
    if(max < 0) return 0;
    return -1;
  }
  int lez(void) const {
    if(max <= 0) return 1;
    if(min > 0) return 0;
    return -1;
  }
  int gtz(void) const {
    if(min > 0) return 1;
    if(max <= 0) return 0;
    return -1;
  }
  int ltz(void) const {
    if(max < 0) return 1;
    if(min >= 0) return 0;
    return -1;
  }
};

static inline value_range operator+(const value_range &a, const value_range &b) {
  return value_range(a.min + b.min, a.max + b.max);
}

static inline value_range operator-(const value_range &a, const value_range &b) {
  return value_range(a.min - b.max, a.max - b.min);
}

static inline value_range operator*(const value_range &a, const value_range &b) {
  // need to handle all +/- {a,b}.{min,max}
  if(a.is_const() && b.is_const())
    return value_range(a.min*b.min);
  if(a.is_const())
    return value_range(b.min*a.min, b.max*a.min).checkswap();
  if(b.is_const())
    return value_range(a.min*b.min, a.max*b.min).checkswap();
  return value_range();
}

static inline value_range operator/(const value_range &a, const value_range &b) {
  // need to handle all +/- {a,b}.{min,max}
  if(a.is_const() && b.is_const())
    return value_range(a.min/b.min);
  return value_range();
}

#endif
