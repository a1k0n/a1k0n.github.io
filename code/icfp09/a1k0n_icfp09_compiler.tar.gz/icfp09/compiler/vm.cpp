#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <set>
#include <map>
#include "vm.h"
#include "expr.h"
#include "range.h"
#include <iostream>

using namespace std;

int maxframe = 0;

instruction::instruction(unsigned insn, double dmem)
{
  subtype = -1;
  data = dmem;
  instr = insn;
  r1 = (insn>>14)&0x3fff;
  r2 = insn&0x3fff;
  switch(insn>>28) {
    case 0: // s-instr
      {
        unsigned op = (insn>>24)&0x0f;
        unsigned imm = (insn>>21)&0x07;
        r1 = r2;
        r2 = -1;

        switch(op) {
          case 0: // noop
            type = instruction::Noop;
            break;
          case 1: // cmpz
            type = Cmpz;
            subtype = imm;
            break;
          case 2: // sqrt
          case 3: // copy
            type = ALU1;
            subtype = op;
            break;
          case 4: // input
            type = Input;
            break;
          default: printf("DECODING BUG: S-instr op %d?\n", op);
        }
      }
      break;
    case 1: // add 
    case 2: // sub
    case 3: // mult 
    case 4: // div
      type = ALU2;
      subtype = insn>>28;
      break;
    case 5: // output
      type = Output;
      break;
    case 6: // phi (cmov)
      type = Phi;
      break;
    default: printf("DECODING BUG: D-instr op %d?\n", insn>>28);
  }
}

instruction insns[16384];

void read_obf(const char *fname)
{
  FILE *fp = fopen(fname, "rb");
  if(!fp) {
    printf("cannot open %s\n", fname);
    exit(-1);
  }

  unsigned char frame[12];
  double *d0   = (double*) &frame[0];
  unsigned *i0 = (unsigned*) &frame[8];
  double *d1   = (double*) &frame[4];
  unsigned *i1 = (unsigned*) &frame[0];
  int frameaddr = 0;
  while(fread(frame, 1, 12, fp) == 12) {
    if(frameaddr&1)
      insns[frameaddr] = instruction(*i1, *d1);
    else
      insns[frameaddr] = instruction(*i0, *d0);
    frameaddr++;
  }
  maxframe = frameaddr;

  fclose(fp);
}

void vm_dump_consts(void)
{
  printf("const double ");
  int n = 0;
  for(int ip=0;ip<maxframe;ip++) {
    if(insns[ip].type == instruction::Noop) {
      printf("%sc%x=%g", n%5==4 ? ",\n  " : n ? ", " : "", ip, insns[ip].data);
      n++;
    }
  }
  printf(";\n\n");
}

void vm_dump_forwardrefs(void)
{
  printf("struct vm_state {\n  double ");
  int n = 0;
  int is_state[16384];
  memset(is_state, 0, sizeof(is_state));
  for(int ip=0;ip<maxframe;ip++) {
    int r1 = insns[ip].r1;
    int r2 = insns[ip].r2;
    switch(insns[ip].type) {
      case instruction::ALU1:
      case instruction::Cmpz:
      case instruction::ALU2:
      case instruction::Phi:
        if(r1 > ip && !is_state[r1] && insns[r1].type != instruction::Noop) {
          is_state[r1] = 1;
          printf("%sd%d", n%8==7 ? ",\n         " : n ? ", " : "", r1);
          n++;
        }
        break;
      default:
        break;
    }
    switch(insns[ip].type) {
      case instruction::ALU2:
      case instruction::Phi:
        if(r2 > ip && !is_state[r2] && insns[r2].type != instruction::Noop) {
          is_state[r2] = 1;
          printf("%sd%d", n%8==7 ? ",\n         " : n ? ", " : "", r2);
          n++;
        }
        break;
      default:
        break;
    }
  }
  printf(";\n};\n\n");
  fflush(stdout);
}

expression *reg[16384];
int is_state[16384];

expression *get_reg(int r)
{
  // assumes vm_dump(pass=1) will switch these const(0)s out
  if(!reg[r]) {
    if(insns[r].type == instruction::Noop) {
      reg[r] = gen_const(insns[r].data);
    } else {
      is_state[r] = 1;
      reg[r] = gen_const(0);
    }
  }
  return reg[r];
}

void set_reg(int r, expression *e)
{
  if(is_state[r]) {
    e->spill(cout);
    cout << "s->d" << r << " = " << e << ";\n  ";
  }
  reg[r] = e;
}

void vm_dump(int pass, int scenario)
{
  if(pass == 0) {
    memset(reg, 0, sizeof(reg));
    memset(is_state, 0, sizeof(is_state));
  } else {
    for(int i=0;i<16384;i++) {
      if(is_state[i]) {
        // TODO: try to determine a value range based on the expression
        if(reg[i]->val().min == 1)
          reg[i] = gen_ref(i, false, value_range(1, INFINITY));
        else
          reg[i] = gen_ref(i, false, value_range());
      }
    }
  }
  
  expression *z = NULL;

  for(int ip=0;ip<maxframe;ip++) {
    instruction i = insns[ip];
    switch(i.type) {
      case instruction::Noop:
        if(!reg[ip])
          set_reg(ip, gen_const(i.data));
        break;
      case instruction::Cmpz:
        z = gen_cmpz(get_reg(i.r1), i.subtype);
        break;
      case instruction::ALU1:
        expression *er1 = get_reg(i.r1);
        switch(i.subtype) {
          case 2: // sqrt
            set_reg(ip, gen_sqrt(er1));
            break;
          case 3: // copy
            set_reg(ip, er1);
            break;
        }
        break;
      case instruction::Input:
        {
          value_range v;
          if(i.r1 == 16000)
            v = value_range(scenario);
          else if(pass == 0)
            v = value_range(0);

          set_reg(ip, gen_ref(i.r1, 1, v));
        }
        break;
      case instruction::ALU2:
        switch(i.subtype) {
          case 1: set_reg(ip, gen_add(get_reg(i.r1), get_reg(i.r2))); break;
          case 2: set_reg(ip, gen_sub(get_reg(i.r1), get_reg(i.r2))); break;
          case 3: set_reg(ip, gen_mul(get_reg(i.r1), get_reg(i.r2))); break;
          case 4: set_reg(ip, gen_div(get_reg(i.r1), get_reg(i.r2))); break;
        }
        break;
      case instruction::Output:
        get_reg(i.r2)->spill(cout);
        cout << "output[" << i.r1 << "] = " << get_reg(i.r2) << ";\n  ";
        break;
      case instruction::Phi:
        set_reg(ip, gen_phi(z, get_reg(i.r1), get_reg(i.r2)));
        break;
    }
  }
}


