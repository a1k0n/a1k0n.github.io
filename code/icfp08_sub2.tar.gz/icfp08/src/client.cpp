#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include <map>
#include <vector>
#include <queue>

const float rover_radius = 0.5;
const float martian_radius = 0.4;
const int lookahead_steps = 100;
const float lookahead_dt = 0.01;
const float lookahead_t = lookahead_steps*lookahead_dt;

#define MAX(a,b) ((a<b)?b:a)

struct MarsObject
{
  float x,y,r; // r is the minkowski sum of the object and the rover, e.g. r += 0.5.
  char type;
  MarsObject() {};
  MarsObject(char t, float _x, float _y, float _r) {
    type=t;
    x=_x,y=_y,r=_r;
  }
  bool collide(float x2, float y2) {
    float r2 = (x2-x)*(x2-x) + (y2-y)*(y2-y);
    return r2 <= r*r;
  }
  int collide_penalty();
};

struct Martian
{
  float x,y,dx,dy,hx,hy;
  unsigned ts;
  Martian() {}
  Martian(unsigned _ts, float _x, float _y, float a, float v) {
    ts=_ts; x=_x; y=_y; 
    hx=cos((180.0/M_PI)*a);
    hy=sin((180.0/M_PI)*a);
    dx=v*hx;
    dy=v*hy;
  }
};

struct obj_id
{
  float x, y;
  obj_id() {}
  obj_id(float _x, float _y) { x=_x; y=_y; }
};

struct ltobjid {
  bool operator()(const obj_id &o1, const obj_id &o2) const {
    return (o1.x == o2.x) ? o1.y < o2.y : o1.x < o2.x;
  }
};

typedef std::map<obj_id, MarsObject*, ltobjid> ObjMap;

struct State
{
  float dx, dy; 
  float time_limit; 
  float min_sensor, max_sensor; 
  float max_speed; 
  float max_turn, max_hard_turn;

  unsigned ts, last_ts; // last received timestamp

  float x,y; // position
  float a; // angle, degrees
  float v; // velocity
  float w; // estimated angular velocity

  bool collision;
  bool started;

  int turn_state;
  int move_state;
  int last_move_state;
  int last_turn_state;

  // estimate acceleration and braking
  float a_est, b_est, wk_est;
  float Tp_est; // end-to-end processing time estimate
  float lastv; // previous velocity
  float lasta; // previous angle
  float lastw; // previous angular velocity (estimate)
  unsigned a_samples, b_samples, Tp_samples, wk_samples;

  float accel() const { return a_samples ? a_est/a_samples : 1; } // prior: 1 m/s^2?
  float brake() const { return b_samples ? b_est/b_samples : -1; } // -1 m/s^2
  float Tproc() const { return Tp_samples ? Tp_est/Tp_samples : 0.045; } // 45 milliseconds?
  float winertia() const { return wk_samples ? wk_est/wk_samples : 0.45; } // e^-t angular inertia?

  float home_radius;

  // need to make this a quadtree at some point?
  ObjMap objs;
  std::vector<Martian> martians;

  void init(void) {
    objs.clear();
    home_radius = 0.1;
    reset();
    a_est = b_est = Tp_est = wk_est = 0;
    a_samples = b_samples = Tp_samples = wk_samples = 0;
  }

  void reset(void) {
    last_turn_state = turn_state = 0; // -2 to +2
    last_move_state = move_state = 0; // -1 to +1
    lastv = 0;
    lasta = 0;
    lastw = 0;
    w = 0;
    ts = last_ts = 0;
    collision = false;
    started = false;
  }

  void update_estimates(void);
  void choose_move(int &desired_turn, int &desired_acc);
  void send_move(int fd);
} map;

int MarsObject::collide_penalty() {
  if(type == 'b') return map.dx+map.dy+lookahead_steps;
  else return 10000000;
}

float calc_traversal_time(float dist, float s0) {
  // no, seriously, this is correct (for a linear movement).  thanks, steve wolfram.
  float m = map.max_speed;
  float m2 = m*m;
  float s02 = s0*s0;
  float a = map.accel();
  return m*(acosh(exp(a*dist/m2)/sqrt(1-s02/m2)) - atanh(s0/m)) / a;
}

float degs_per_sec(int turn_state)
{
  // negative 'turn' is counterclockwise, meaning positive angle
  return ((turn_state == -2) ? map.max_hard_turn :
          (turn_state == -1) ? map.max_turn :
          (turn_state == 1) ? -map.max_turn :
          (turn_state == 2) ? -map.max_hard_turn : 0);
}

float bisect(float min, float max, float target, float (*fn)(float))
{
  for(;;) {
    float avg = (max+min)/2;
    if(max-min < 1e-3) return avg;
    if(fn(avg) > target) max=avg;
    else min=avg;
  }
  // not reached
}

float wk_Twmax;
float wk_fn(float x)
{
  return log(cosh(x * wk_Twmax))/x;
}

float next_w(float w0, float t, int turn_state)
{
  float k = map.winertia();
  float wmax = degs_per_sec(turn_state);
  float a = k*wmax*wmax;
  if(wmax < 0)
    return w0 - t*(a - k*w0*w0);
  return w0 + t*(a - k*w0*w0);
}

float acceleration(int move_state)
{
  float aa = map.accel();
  float bb = map.brake();
  return ((move_state == 1) ? aa : 
          (move_state == -1) ? bb : 0);
}

#if 0
// binary search for the angular damping constant
float wk_search(float t, float sqrtwmax, float w0, float a, float kmin, float kmax)
{
  float theta = log(cosh(t*sqrtwmax + atanh(k*
}
#endif

// pseudo-euler-integration-thingy
void fastfwd(float &x, float &y, float &a, float &v, float &w, float T)
{
  float accrate = acceleration(map.move_state);
  float aa = map.accel();
  for(float t=0;t<T;) {
    float h = fmin(T-t, lookahead_dt);
    // compute heading
    float hx = cos(a*M_PI/180.0);
    float hy = sin(a*M_PI/180.0);

    float w2 = next_w(w, h, map.turn_state);
    float v2 = v + h*(accrate - (aa*v*v/(map.max_speed*map.max_speed)));
    if(v2<0) v2=0;

    x += (v+v2)*hx*h*0.5;
    y += (v+v2)*hy*h*0.5;
    a += (w+w2)*h*0.5;
    v = v2;
    w = w2;
    t += h;
  }
}

// heuristic value of state; lower scores are better
float value_after(float &x, float &y, float &a, float &v, float &w, bool &dead, int turn, int acc)
{
  float accrate = acceleration(acc);
  float aa = map.accel();

  float hx,hy;
  float martian_penalty=0;
  // do integration of path
  for(int i=0;i<lookahead_steps;i++) {
    // euler step, blah
    // should do rk4 here.
    //
    // compute heading
    hx = cos(a*M_PI/180.0);
    hy = sin(a*M_PI/180.0);
    const float h = lookahead_dt;

    float w2 = next_w(w, h, turn);
    float v2 = v + h*(accrate - (aa*v*v/(map.max_speed*map.max_speed)));
    if(v2<0) v2=0;

    x += (v+v2)*hx*h*0.5;
    y += (v+v2)*hy*h*0.5;
    a += (w+w2)*h*0.5;
    v = v2;
    w = w2;

    // i guess we could estimate the bounce behavior for rocks but... whatever
    ObjMap::iterator itr;
    for(itr=map.objs.begin();itr!=map.objs.end();itr++) {
      if(itr->second->collide(x,y)) {
        dead = true;
        return itr->second->collide_penalty() - i;
      }
    }

    /* first ten lookahead steps: if we're home free then do it */
    if(i<10) {
      float dist = sqrt((x*x)+(y*y));
      if(dist < map.home_radius)
        return 0.1*i; // win!
    }


    // try to stay behind martians' heading so they can't get you
    for(unsigned j=0;j<map.martians.size();j++) {
      float mhx = map.martians[j].hx;
      float mhy = map.martians[j].hy;
      float mx = map.martians[j].x + map.martians[j].dx*i*lookahead_dt;
      float my = map.martians[j].y + map.martians[j].dy*i*lookahead_dt;
      float mdist = sqrt((x-mx)*(x-mx)+(y-my)*(y-my)) - rover_radius - martian_radius;
      float dx = (x-mx)/mdist;
      float dy = (y-my)/mdist;
      martian_penalty += (mhx*dx + mhy*dy)/mdist;
    }

  }


  // the value function is the approximate time to reach home base given the
  // current state, which is (time taken to turn toward center) + (time taken
  // to travel to center, given velocity)

  float dist = sqrt((x*x)+(y*y));
#if 0
  if(dist < map.home_radius)
    return 0; // win!
#endif

  // compute time to turn toward center
  float turntime = 0;

//  float dotp = -x*hx-y*hy;
  // can we go straight into home base without turning?
  // project heading along line to origin to see where we'd intersect
//  float xp = x+dotp*hx, 
//        yp = y+dotp*hy;
//  if((xp*xp)+(yp*yp) < map.home_radius*map.home_radius) {
    // yes, we can, if we want, go straight ahead to win
//  } else {
    float turnangle = (180.0/M_PI)*acos((-x*hx-y*hy)/dist);
    turntime = turnangle/map.max_hard_turn;
//  }

  float traversaltime = calc_traversal_time(dist, v);

//  printf("[%d,%d] (%f,%f,%f,%f,%f) turnangle=%f, turntime=%f, traversaltime = %f (%f)\n", 
//         turn,acc, x,y,a,v,w,
//         turnangle, turntime, traversaltime, turntime+10*traversaltime);
  return turntime + traversaltime + martian_penalty; // should be a roughly admissible heuristic
}

// A*-ish
struct move_state
{
  // we naively assume we can instantaneously change our angular velocity here
  float x,y,a,v,w;
  float g,h;
  int firstmove_turn, firstmove_acc;
  move_state() {}
  move_state(float _x, float _y, float _a, float _v, float _w, float _g, float _h,
             int t, int acc)
  { x=_x,y=_y,a=_a,v=_v,w=_w; g=_g,h=_h; firstmove_turn = t; firstmove_acc = acc; }
};

struct lt_move
{
  bool operator()(const move_state &m1, const move_state &m2) const {
    return (m1.g+m1.h) > (m2.g+m2.h);
  }
};


float move_search(int &next_turn, int &next_acc, float x, float y, float a, float v, float w)
{
  std::priority_queue<move_state, std::vector<move_state>, lt_move> open;

  // do best-first search of heuristic + actual score.  since we only care
  // about our next move, prune just enough to rule out crappy moves.

  // if our heuristic is always an underestimate, then g+h can only increase as
  // we search, so you can prune g+h.  hm.

  // we use sum(i=0..n-1) actual time [i] + heuristic time [n]
  // if we hit a crater or a martian, we're done

  float nx=x,ny=y,na=a,nv=v,nw=w;
  // start out with our estimated processing delay ahead of time
  fastfwd(nx,ny,na,nv,nw, map.Tproc());

  // try all possible combinations (5*3) and score them
  for(int turn=-2;turn<=2;turn++) {
    for(int acc=1;acc>=-1;acc--) {
      if(acc == -1 && v == 0) continue; // don't bother braking if we're not moving
      float _x=nx,_y=ny,_a=na,_v=nv,_w=nw;
      bool dead=false;
      float h = value_after(_x,_y,_a,_v,_w,dead, turn, acc);
      if(!dead)
        open.push(move_state(_x,_y,_a,_v,_w, 0,h, turn, acc));
    }
  }

  int deepenings;
  for(deepenings=0;deepenings < 50;deepenings++) {
    if(open.empty()) {
      printf("out of states?!\n");
      break;
    }
    move_state m = open.top();
    open.pop();
    printf("top move: (%f,%f,%f,%f,%f, %d,%d) -> %f,%f=%f\n",
           m.x,m.y,m.a,m.v,m.w, m.firstmove_turn, m.firstmove_acc, m.g,m.h, m.h+m.g);
    for(int turn=-2;turn<=2;turn++) {
      for(int acc=-1;acc<=1;acc++) {
        if(acc == -1 && v == 0) continue; // don't bother braking if we're not moving
        float _x=m.x,_y=m.y,_a=m.a,_v=m.v,_w=m.w;
        bool dead=false;
        float h = value_after(_x,_y,_a,_v,_w,dead, turn, acc);
        if(!dead)
          open.push(move_state(_x,_y,_a,_v,_w, m.g+lookahead_t,h, 
                               m.firstmove_turn, m.firstmove_acc));
      }
    }
  }

  if(!open.empty()) {
    move_state m = open.top();
    printf("after %d deepenings: (%f,%f,%f,%f,%f, %d,%d) -> %f,%f=%f\n",
           deepenings, m.x,m.y,m.a,m.v,m.w, m.firstmove_turn, m.firstmove_acc, m.g, m.h, m.h+m.g);
    next_turn = m.firstmove_turn;
    next_acc = m.firstmove_acc;
    return m.g+m.h;
  } else {
    printf("hmm, nothing i can do.  i'm pretty much dead.\n");
    next_turn=0;
    next_acc=0;
  }
  return 0;
}

void State::choose_move(int &desired_turn, int &desired_acc)
{
// okay, fuck it.  the A* thing just doesn't work!  i need to submit in less than an hour!
//  move_search(desired_turn,desired_acc, x,y,a,v,w);
//
  float nx=x,ny=y,na=a,nv=v,nw=w;
  // start out with our estimated processing delay ahead of time
  fastfwd(nx,ny,na,nv,nw, map.Tproc());

  float besth = 1e30;
  for(int turn=-2;turn<=2;turn++) {
    for(int acc=-1;acc<=1;acc++) {
      if(acc == -1 && v == 0) continue; // don't bother braking if we're not moving
      float _x=nx,_y=ny,_a=na,_v=nv,_w=nw;
      bool dead=false;
      float h = value_after(_x,_y,_a,_v,_w,dead, turn, acc);
      if(!dead && h < besth) {
        desired_turn = turn;
        desired_acc = acc;
        besth = h;
      }
    }
  }
  if(Tp_samples < 3 && a_samples > 10 && move_state == 1) {
    // force a frame of coasting just to get a sample here
    desired_acc = 0;
  }
}

void State::send_move(int fd)
{
  char cmd[32];
  int cmdlen=0;

  int desired_t=0, desired_a=0;
  choose_move(desired_t, desired_a);
  //printf("move chosen: (%d,%d)\n", desired_t, desired_a);

  if(desired_a > move_state) {
    cmd[cmdlen++] = 'a';
    move_state ++;
  }
  if(desired_a < move_state) {
    cmd[cmdlen++] = 'b';
    move_state --;
  }

  if(desired_t < turn_state) {
    cmd[cmdlen++] = 'l';
    turn_state--;
  }
  if(desired_t > turn_state) {
    cmd[cmdlen++] = 'r';
    turn_state++;
  }
  cmd[cmdlen++] = ';';

  // send extra turn cmds in same packet, if necessary
  while(desired_t < turn_state) {
    cmd[cmdlen++] = 'l';
    cmd[cmdlen++] = ';';
    turn_state--;
  }
  while(desired_t > turn_state) {
    cmd[cmdlen++] = 'r';
    cmd[cmdlen++] = ';';
    turn_state++;
  }

  while(desired_a > move_state) {
    cmd[cmdlen++] = 'a';
    cmd[cmdlen++] = ';';
    move_state ++;
  }
  while(desired_a < move_state) {
    cmd[cmdlen++] = 'b';
    cmd[cmdlen++] = ';';
    move_state --;
  }

  if(cmdlen <= 1) return;

  send(fd, cmd, cmdlen, 0);
  cmd[cmdlen]=0;
//  printf("sending: %s\n", cmd);
}

// estimation of parameters

float lerp(float x, float x0, float x1)
{
  return (x0-x)/(x0-x1);
}

void State::update_estimates()
{
  if(ts == last_ts) return;
  if(collision) return;

  if(move_state == 1 && last_move_state == 0 && a_samples) {
    // estimate delay in acceleration (due to processing time)
    float m = max_speed;
    float a = accel();
    float delta = (ts-last_ts)*(1/1000.0);
    float v0 = lastv;
    // t1: time spent coasting before acceleration started
    // vt1_0: velocity given t1 == 0
    float vt1_0 = m*tanh(a*delta/m + atanh(v0/m));
    // vt1_T: velocity given t1 == T
    float vt1_T = v0*m*m/(m*m+a*v0*delta);
    // linearly interpolate
    float t = lerp(v, vt1_0, vt1_T);
    if(t >= 0 && t <= 1) {
      Tp_est += t*delta;
      Tp_samples ++;
//      printf("Tp_est=%f\n", Tproc());
    } else {
//      printf("Tp_est: oob: %f<%f<%f?\n", vt1_T, v, vt1_0);
    }
  }

  if(move_state == 1 && last_move_state == 1) {
    // update acceleration estimate by plugging into the ODE solution:
    // s(t) = m * tanh((a*(t-t0)/m) + atanh(s(0)/m)) where m == max_speed
    // a = (m atanh(s/m) - m atanh(s0/m))/(t-t0)
    float m = max_speed;
    float v0 = lastv;
    // if we're close to our max speed and not accelerating, then don't try to estimate
    if(v > 0.95*max_speed) return; 

    float a = 1000*m*(atanh(v/m) - atanh(v0/m))/(ts-last_ts);
    a_est += a;
    a_samples++;
//    printf("a_est=%f\n", accel());
  }

  // k = a/m^2, so move_state 0 is already estimated

  else if(move_state == -1 && last_move_state == -1) {
    // update acceleration estimate by plugging into the ODE solution:
    // s(t) = m * tanh((a*(t-t0)/m) + atanh(s(0)/m)) where m == max_speed
    // a = (m atanh(s/m) - m atanh(s0/m))/(t-t0)
    float m = max_speed;
    float v0 = lastv;

    // deceleration, a should be negative
    float a = 1000*m*(atanh(v/m) - atanh(v0/m))/(ts-last_ts);
    b_est += a;
    b_samples++;
//    printf("b_est=%f\n", brake());
  }

  if(turn_state != last_turn_state) {
    float delta = (ts-last_ts)*(1/1000.0) - Tproc();
    float da = lasta - a;
    if(da > 180) da = 360 - da;
    da = fabs(da);
    if(fabs(lastw) <= 0.001) {
      // handy, we can calculate k directly!
      wk_Twmax = delta * map.max_hard_turn;
      float k = bisect(0, 10, da, wk_fn);
      wk_est += k;
      wk_samples++;
//      printf("wk_est: %f\n", winertia());
      // we're only gonna get one sample from our first turn command.  hope it's good enough.
    } else {
    }
  } else {
    // blah, not sure how i'm going to do this
    // ideally i'd collect a bunch of data and do conjugate gradient descent in
    // another thread or something but uh, that isn't going to happen with
    // three hours left.
#if 0
    float delta = (ts-last_ts)*(1/1000.0);
    float da = fabs(lasta - a);
    if(da > 0) {
      // we can calc k from the drift, provided we know wlast!
      // which we don't, really...
      // we'll have to iteratively search for k...
      float tk0 = delta*lastw; // theta given k=0
    }
#endif
  }
}

// packet parser

void read_init(const char *init)
{
  map.init();
  sscanf(init+2, "%f %f %f %f %f %f %f %f ;", &map.dx, &map.dy, 
         &map.time_limit, &map.min_sensor, &map.max_sensor, 
         &map.max_speed, &map.max_turn, &map.max_hard_turn);
  //printf("init; world size = %fx%f\n", map.dx, map.dy);
}

void read_telemetry(const char *t)
{
  char ctl[4];
  int next;
  char end;
  //printf("telemetry: %s\n", t);
  map.last_ts = map.ts;
  map.collision = false;
  map.started = true;
  map.martians.clear();
  if(7 == sscanf(t+2, "%u %3s %f %f %f %f %c%n", &map.ts, ctl, &map.x, 
                 &map.y, &map.a, &map.v, &end, &next)) {
    // yep.
    if(map.ts != map.last_ts) {
      float da = map.a - map.lasta;
      if(da > 180) da = 360 - da;
      map.w = da*1000/(map.ts-map.last_ts); // sort of bad estimate of w
    }

#ifdef VERBOSE
    printf("%0.2f,%0.2f; heading %0.1f @%0.4fm/s (w=%f), action=%s [%d,%d] -> [%d,%d]\n", 
           map.x, map.y, map.a, map.v, map.w, ctl, 
           map.last_turn_state, map.last_move_state,
           map.turn_state, map.move_state);
#endif
    int ms=0;

    switch(ctl[0]) {
      case 'a': ms = 1; break;
      case '-': ms = 0; break;
      case 'b': ms = -1; break;
    }
    int ts=0;
    switch(ctl[1]) {
      case 'L': ts = -2; break;
      case 'l': ts = -1; break;
      case '-': ts = 0; break;
      case 'r': ts = 1; break;
      case 'R': ts = 2; break;
    }
    if(ms != map.move_state || ts != map.turn_state) { 
#ifdef VERBOSE
      printf("desync!? [%d,%d] -> [%d,%d]\n", map.move_state, map.turn_state,
             ms, ts);
#endif
      map.move_state = ms; 
      map.turn_state = ts; 
      map.collision = true; // don't update estimates?
    }

    for(;;) {
      t += next+1;
      switch(t[0]) {
        case ';':
          return;
        case 'm':
          // martian!
          {
            float mx, my, ma, mv;
            sscanf(t+2, "%f %f %f %f %c%n", &mx, &my, &ma, &mv, &end, &next);
            map.martians.push_back(Martian(map.ts, mx, my, ma, mv));
            break;
          }
        case 'b':
        case 'c':
        case 'h':
          {
            float mx, my, mr;
            sscanf(t+2, "%f %f %f %c%n", &mx, &my, &mr, &end, &next);
            if(t[0] == 'h') {
              // home base.  yep.
              map.home_radius = mr;
            } else {
              if(t[0] == 'b') mr += rover_radius;
              else mr += 0.1; // give us some margin around a crater since our control isn't exact
              ObjMap::iterator itr = map.objs.find(obj_id(mx,my));
              if(itr == map.objs.end()) {
                // C++ is just beautiful, isn't it?  ahem.
                map.objs.insert(std::pair<obj_id, MarsObject*>(obj_id(mx, my), new MarsObject(t[0], mx, my, mr)));
                //printf("  object %c found @%f,%f r=%f\n", t[0], mx, my, mr);
              } else {
                // just use the maximum radius of colocated objects
                itr->second->r = MAX(itr->second->r, mr);
                // craters are more significant than boulders (heh!)
                itr->second->type = MAX(itr->second->type, t[0]);
              }
            }
          }
          break;
        default:
          printf("out of sync? t=%s\n", t);
          return;
      }
    }
  } else {
    printf("read_telemetry: unable to parse %s\n", t);
  }
}

int read_pkt(const char *pkt, int len)
{
  // scan for a semicolon
  int i;
  for(i=0;i<len;i++)
    if(pkt[i] == ';') break;
  if(i == len) return 0; // didn't find it
  switch(pkt[0]) {
    case 'I': // initialization
      read_init(pkt);
      break;
    case 'T': // telemetry
      read_telemetry(pkt);
      break;
    case 'B': // boundary crash
      //printf("boing!  hit boundary or object\n");
      map.collision = true;
      break;
    case 'C': // crater crash :O
      //printf(":O crashed into crater\n");
      break;
    case 'K': // killed by a martian X(
      //printf("X( killed by martian\n");
      break;
    case 'S': // win!
      break;
    case 'E': // game over, man
      //printf("round ended\n");
      map.reset();
      break;
    default:
      printf("unknown packet %c?\n", pkt[0]);
  }
  return i+1;
}


// boring crap below

int connect_tcp(const char *hostname, int port)
{
  struct sockaddr_in sa;
  struct hostent *host;
  int fd;

  host=gethostbyname(hostname);
  if(!host) return -1;

  memcpy((void*)&sa.sin_addr, (void*)host->h_addr, host->h_length);

  // create a non-blocking socket
  fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) {
    perror("socket");
    return -1;
  }
  sa.sin_family=AF_INET;
  sa.sin_port=htons(port);
  if(connect(fd, (struct sockaddr*) &sa, sizeof(sa))!=0) {
    perror("connect");
    return -1;
  }
  int flag = 1;
  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
//  fcntl(fd, F_SETFL, O_NONBLOCK);
  return fd;
}

int main(int argc, char **argv)
{
  static char *buf=NULL;
  static int bufsiz = 0;
  if(argc < 3) {
    printf("usage: %s hostname port\n", argv[0]);
    return -1;
  }

  int fd = connect_tcp(argv[1], atoi(argv[2]));
  if(fd < 0) return -1;

  buf = (char*) malloc(4096);
  bufsiz = 4096;
  for(;;) {
    int len=0;
    do {
      int l;
      l = recv(fd, buf+len, bufsiz-len, 0);
      if(l == 0) {
        printf("disconnected\n");
        return 0;
      }
      if(l < 0) {
        perror("recv");
        return 0;
      }
      len += l;
      if(l == bufsiz-len) {
        bufsiz += 4096;
        buf = (char*) realloc((void*) buf, bufsiz);
        continue;
      }
    } while(0);
    int processed = 0;
    while(processed < len)
      processed += read_pkt(buf+processed, len-processed);
    memmove(buf, buf+processed, len-processed);

    if(map.started) {
      map.update_estimates();
      map.lastw = map.w;
      map.lastv = map.v;
      map.lasta = map.a;
      map.last_move_state = map.move_state;
      map.last_turn_state = map.turn_state;
      map.send_move(fd);
    }
  }
}

